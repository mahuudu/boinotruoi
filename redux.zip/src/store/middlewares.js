export const asyncer = (dispatch, state) => (action) =>
  typeof action === 'function' ? action(dispatch, state) : dispatch(action)
;
  
const colorToActionMap = {
  'SUCCESS': 'green',
  'ERROR': 'red'
}

export const logger = (
  action,
  prevState,
  currentState
) => {
  const actionTypeBreakdown = action.type.split('_');
  const actionType = actionTypeBreakdown[actionTypeBreakdown.length - 1];
  const logColor = colorToActionMap[actionType] || 'blue';
  console.groupCollapsed('%c ACTION:', `color: ${logColor}`, action.type);
  console.log('%c Action:', 'color: orange', action);
  console.log('%c Prev State:', 'color: red', prevState);
  console.log('%c next State:', 'color: green', currentState);
  console.groupEnd();
};

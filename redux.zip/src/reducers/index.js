import uiReducer, { initialState as uiReducerInitialState } from './ui';
import authReducer, { initialState as authReducerInitialState } from './auth';
import configReducer, { initialState as configReducerInitialState } from './config';
import meReducer, { initialState as meReducerInitialState } from './me';

import { logger } from './../store/middlewares';

export const initialState = {
  ui: uiReducerInitialState,
  auth: authReducerInitialState,
  config: configReducerInitialState,
  me: meReducerInitialState
};

export default function mainReducer(state, action) {
  // Receiving previous state here
  const { ui, auth, me, config } = state;

  // Receiving current state here
  const currentState = {
    ui: uiReducer(ui, action),
    auth: authReducer(auth, action),
    config: configReducer(config, action),
    me: meReducer(me, action)
  };

  // Middlewares
  logger(action, state, currentState);

  return currentState;
}


export const FALCON_BINARY_CONNECTION_STATE = { // TODO: see if this is needed
  connected: 1,
  killed: 2, 
  disconnected: 3
}
export const initialState = {
  status: {
    isFetching: true,
    data: null,
    error: null
  },
  connect: {
    isRequesting: false,
    data: FALCON_BINARY_CONNECTION_STATE.disconnected,
    error: null
  },
};

const authReducer = (state = initialState, action) => {
  switch (action.type) {
    case 'AUTH_STATUS_FETCHING':
      return {
        ...state,
        status: {
          ...state.status,
          isFetching: true
        }
      }

    case 'AUTH_STATUS_SUCCESS':
      return {
        ...state,
        status: {
          ...state.status,
          isFetching: false,
          data: action.data
        },
        connect: {
          ...state.connect,
          data: action.data && action.data.status ? FALCON_BINARY_CONNECTION_STATE.connected : FALCON_BINARY_CONNECTION_STATE.disconnected
        }
      }

    case 'AUTH_STATUS_ERROR':
      return {
        ...state,
        status: {
          ...state.status,
          isFetching: false,
          error: action.error
        }
      }

    case 'AUTH_CONNECTION_REQUESTING':
      return {
        ...state,
        connect: {
          isRequesting: true,
          data: null,
          error: null
        }
    }

    case 'AUTH_CONNECTION_SUCCESS':
      return {
        ...state,
        connect: {
          isRequesting: false,
          data: FALCON_BINARY_CONNECTION_STATE.connected,
          error: null
        }
      }

    case 'AUTH_CONNECTION_ERROR':
      return {
        ...state,
        connect: {
          isRequesting: false,
          data: null,
          error: action.error
      }
    }

    case 'AUTH_DISCONNECT_REQUESTING':
      return {
        ...state,
        connect: {
          isRequesting: true,
          data: null,
          error: null
        }
      }

    case 'AUTH_DISCONNECT_SUCCESS':
      return {
        ...state,
        connect: {
          isRequesting: false,
          data: FALCON_BINARY_CONNECTION_STATE.disconnected,
          error: null
        }
      }

    case 'AUTH_DISCONNECT_ERROR':
      return {
        ...state,
        connect: {
          isRequesting: false,
          data: null,
          error: action.error
        }
      }

    case 'AUTH_RECONNECT_REQUESTING':
      return {
        ...state,
        connect: {
          isRequesting: true,
          data: null,
          error: null
        }
      }

    case 'AUTH_RECONNECT_SUCCESS':
      return {
        ...state,
        connect: {
          isRequesting: false,
          data: FALCON_BINARY_CONNECTION_STATE.connected,
          error: null
        }
      }
    case 'AUTH_RECONNECT_ERROR':
      return {
        ...state,
        connect: {
          isRequesting: false,
          data: null,
          error: action.error
        }
      }

    case 'AUTH_KILL_REQUESTING':
      return {
        ...state,
        connect: {
          isRequesting: true,
          data: null,
          error: null
        }
      }

    case 'AUTH_KILL_SUCCESS':
      return {
        ...state,
        connect: {
          isRequesting: false,
          data: FALCON_BINARY_CONNECTION_STATE.killed,
          error: action.error
        }
      }
    case 'AUTH_KILL_ERROR' :
      return {
        ...state,
        connect: {
          isRequesting: false,
          data: null,
          error: null
        }
      }
      
    default:
      return state;
  }
}

export default authReducer;

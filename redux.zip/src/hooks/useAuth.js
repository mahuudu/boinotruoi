import { useGlobalStore } from '../store';

import bindActions from '../store/bindActions';
import * as actions from '../actions/auth';

/**
 * useAuth Custom Hook
 */
const useAuth = () => {
  const { state, dispatch } = useGlobalStore();

  // List of Props
  const { auth } = state;

  // Bind Actions
  const authActions = bindActions({
    ...actions  
  }, dispatch);

  return { auth, ...authActions };
}

export default useAuth;

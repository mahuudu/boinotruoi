import { useGlobalStore } from '../store';

import bindActions from '../store/bindActions';
import * as actions from '../actions/me';

/**
 * useMe Custom Hook
 */
const useMe = () => {
  const { state, dispatch } = useGlobalStore();

  // List of Props
  const { me } = state;

  // Bind Actions
  const meActions = bindActions({
    ...actions  
  }, dispatch);

  return { me, ...meActions };
}

export default useMe;

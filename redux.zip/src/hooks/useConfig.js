import { useGlobalStore } from '../store';

import bindActions from '../store/bindActions';
import * as actions from '../actions/config';

/**
 * useConfig Custom Hook
 */
const useConfig = () => {
  const { state, dispatch } = useGlobalStore();

  // List of Props
  const { config } = state;

  // Bind Actions
  const configActions = bindActions({
    ...actions  
  }, dispatch);

  return { config, ...configActions };
}

export default useConfig;

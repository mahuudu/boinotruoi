import React, { useEffect, useState } from 'react';
import classnames from 'classnames';

import Dashboard from './../Dashboard';
import Key from './../Key';
import { Header, MessageBox, Toastr, AlertBox } from './../../components';
import PersistenceAlert from './../PersistenceAlert';

import { useAuth, useUI, useConfig } from './../../hooks';
import { PERFORMANCE_REPORT_EVENT_TIMEOUT } from './../../constants/app';
import { sendEvent, sendBeacon } from './../../lib/analytics';

import './styles.scss';

const App = ({}) => {
  const { getAuthStatus, auth } = useAuth();
  const { ui, setUI, resetUI } = useUI();

  const [isConfigError, setIsConfigError] = useState(false);

  const handleAlertClose = () => {
    resetUI('alert');
    if (ui.alert.onClose) {
      ui.alert.onClose();
    }
  }

  useEffect(() => {
    // Send performance report after 15s of app launch
    setTimeout(() => {
      sendEvent({
        name: 'PERFORMANCE_REPORT',
        value: window.performance || null
      });
    }, PERFORMANCE_REPORT_EVENT_TIMEOUT);

    // Send performance report on window close, if the time lapsed since app launch is less than 15s
    window.addEventListener('beforeunload', (ev) => {
      ev.preventDefault();
      if (window.performance && window.performance.now() <= PERFORMANCE_REPORT_EVENT_TIMEOUT) {
        sendBeacon({
          name: 'PERFORMANCE_REPORT',
          value: window.performance || null
        });
      }
      return ev.returnValue;
    });

    let windowBackgroundDuration = 0;
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        windowBackgroundDuration = Date.now();
      } else {
        windowBackgroundDuration = Date.now() - windowBackgroundDuration;
      }
      if (!document.hidden) {
        sendEvent({
          name: 'APP_IN_BACKGROUND',
          value: windowBackgroundDuration / 1000,
        });
      }
    }, false);

    getAuthStatus();
  }, []);

  useEffect(() => {
    // TODO: check if needed. Handle the whole block differently
    auth.connect.data === 1 && (
      sendEvent({
        name: 'PAGE_EXIT',
        value: 'KEY'
      })
    );
    // If the user has proxy settings due to which the api server is not able to connect,
    // the dashboard needs to show the config error state.
    if (auth.connect.error && auth.connect.error.message.includes("Could not connect")) {
      setIsConfigError(true);
    }
  }, [auth.connect.isRequesting]);

  useEffect(() => {
    if (auth.status.data && auth.status.data.status) {
      resetUI('alert');
    }
  }, [auth.status.data]);

  const appContainerClasses = classnames('app__container', {
    'loading loading--big': auth.status.isFetching
  });

  const setToastrVisibility = (isActive) => {
    setUI('toastr', {
      isActive,
    });
  };

  return (
    <div className="app">

      {/* This is always rendered so as to have controlled animations on their appearance */}
      <Toastr
        text={ui.toastr.text}
        theme={ui.toastr.theme}
        isActive={ui.toastr.isActive}
        setToastrVisibility={setToastrVisibility}
      />

      {/* This is always rendered so as to have controlled animations on their appearance */}
      <AlertBox
        title={ui.alert.title}
        onClose={handleAlertClose}
        closeRef={ui.alert.closeRef}
        parentRef={ui.alert.parentRef}
        content={ui.alert.content}
        isActive={ui.alert.isActive}
        withIcon={ui.alert.withIcon}
        withClose={ui.alert.withClose}
        iconType={ui.alert.iconType}
      />

      <Header />

      <div className={appContainerClasses}>

        {(() => {
          if (isConfigError) {
            return <Dashboard isConfigError={isConfigError} />;
          }
          
          if (auth.status.isFetching) {
            return null;
          }

          if (auth.status.error || !auth.status.data) {
            return (
              <MessageBox
                className="align-self-center mt-auto mb-auto"
                danger
                text={auth.status.error ? auth.status.error.message : 'Error fetching connection status'}
              />
            );
          }

          if (!auth.status.data.status) {
            return <Key />;
          }

          return <Dashboard />;

        })()}

      </div>
    </div>
  );
}

export default App;

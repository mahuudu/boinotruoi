import { authApi } from '../api';

// Connection Status
const handleFetchingAuthStatus = () => {
  return {
    type: 'AUTH_STATUS_FETCHING'
  }
};

const handleAuthStatusFetchSuccess = (data) => {
  return {
    type: 'AUTH_STATUS_SUCCESS',
    data
  }
};

const handleAuthStatusFetchFailure = (error) => {
  return {
    type: 'AUTH_STATUS_ERROR',
    error
  }
};
// Connection Status ends

// Post Connection Request
const handleAuthConnectionInit = () => {
  return {
    type: 'AUTH_CONNECTION_REQUESTING'
  }
};

const handleAuthConnectionSuccess = (data) => {
  return {
    type: 'AUTH_CONNECTION_SUCCESS',
    data
  }
};

const handleAuthConnectionFailure = (error) => {
  return {
    type: 'AUTH_CONNECTION_ERROR',
    error
  }
};
// Post Connection Request ends

// Kill Connection Request
const handleDisconnectInit = () => {
  return {
    type: 'AUTH_DISCONNECT_REQUESTING'
  }
};

const handleDisconnectSuccess = (data) => {
  return {
    type: 'AUTH_DISCONNECT_SUCCESS',
    data
  }
};

const  handleDisconnectFailure = (error) => {
  return {
    type: 'AUTH_DISCONNECT_ERROR',
    error
  }
};
// Kill Connection Request
const handleReconnectInit = () => {
  return {
    type: 'AUTH_RECONNECT_REQUESTING'
  }
};

const handleReconnectSuccess = (data) => {
  return {
    type: 'AUTH_RECONNECT_SUCCESS',
    data
  }
};

const handleReconnectFailure = (error) => {
  return {
    type: 'AUTH_RECONNECT_ERROR',
    error
  }
};

// Kill Connection Request
const handleKillAuthInit = () => {
  return {
    type: 'AUTH_KILL_REQUESTING'
  }
};

const handleKillAuthSuccess = (data, successCb) => {
  if (successCb) {
    successCb();
  }
  return {
    type: 'AUTH_KILL_SUCCESS',
    data
  }
};

const handleKillAuthFailure = (error) => {
  return {
    type: 'AUTH_KILL_ERROR',
    error
  }
};
// Kill Connection Request ends

export const getAuthStatus = () => {
  return async (dispatch) => {
    dispatch(handleFetchingAuthStatus());
    authApi.fetchConnectionStatus()
      .then((data) => dispatch(handleAuthStatusFetchSuccess(data)))
      .catch((err) => dispatch(handleAuthStatusFetchFailure(err)))
    ;
  }
};

export const requestAuthConnection = (key) => {
  return async (dispatch) => {
    dispatch(handleAuthConnectionInit());
    authApi.postConnectionRequest(key)
      .then((data) => dispatch(handleAuthConnectionSuccess(data)))
      .catch((err) => dispatch(handleAuthConnectionFailure(err)))
    ;
  }
};

export const disconnectConnection = () => {
  return async (dispatch) => {
    dispatch(handleDisconnectInit());
    authApi.disconnectConnection()
      .then((data) => dispatch(handleDisconnectSuccess(data)))
      .catch((err) => dispatch(handleDisconnectFailure(err)))
    ;
  }
}

export const reconnectConnection = () => {
  return async (dispatch) => {
    dispatch(handleReconnectInit());
    authApi.reconnectConnection()
      .then((data) => dispatch(handleReconnectSuccess(data)))
      .catch((err) => dispatch(handleReconnectFailure(err)))
    ;
  }
}

export const killConnection = () => {
  return async (dispatch) => {
    dispatch(handleKillAuthInit());
    authApi.killConnection()
      .then((data) => dispatch(handleKillAuthSuccess(data)))
      .catch((err) => dispatch(handleKillAuthFailure(err)))
    ;
  }
};

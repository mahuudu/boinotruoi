import { meApi } from '../api';
import { NETWORK_LOGS_IDLE_TIMEOUT } from '../constants/app';

// Profile request
const handleProfileRequest = () => {
  return {
    type: 'GET_ME_INIT'
  }
};

const handleProfileRequestSuccess = (data) => {
  return {
    type: 'GET_ME_SUCCESS',
    data
  }
};

const handleProfileRequestError = (error) => {
  return {
    type: 'GET_ME_ERROR',
    error
  }
};
// Profile request ends

// Post Parameters Request
const handlePostConfigureInit = () => {
  return {
    type: 'POST_CONFIGURE_INIT'
  }
};

const handlePostConfigureSuccess = (data) => {
  return {
    type: 'POST_CONFIGURE_SUCCESS',
    data
  }
};

const handlePostConfigureFailure = (error) => {
  return {
    type: 'POST_CONFIGURE_ERROR',
    error
  }
};

// Network Logs request
const handleNetworkLogsRequestInit = () => {
  return {
    type: 'GET_NETWORK_LOGS_INIT'
  }
};

const handleNetworkLogsRequestSuccess = (data) => {
  return {
    type: 'GET_NETWORK_LOGS_SUCCESS',
    data
  }
};

const setNetworkLogsStatus = (data) => {
  return {
    type: 'NETWORK_LOGS_STATUS_SET',
    data
  }
};

const handleNetworkLogsRequestError = (error) => {
  return {
    type: 'GET_NETWORK_LOGS_ERROR',
    error
  }
};

// Network Logs request ends

const handleDebugConnectionRequest = () => {
  return {
    type: 'DEBUG_CONNECTION_REQUEST',
  }
}

const handleDebugConnectionRequestSuccess = (data) => {
  return {
    type: 'DEBUG_CONNECTION_SUCCESS',
    data
  }
}

const handleDebugConnectionRequestError = (error) => {
  return {
    type: 'DEBUG_CONNECTION_ERROR',
    error
  }
}

// Debug Connection request ends


const handleDebugURLRequest = () => {
  return {
    type: 'DEBUG_URL_REQUEST',
  }
}

const handleDebugURLRequestSuccess = (data) => {
  return {
    type: 'DEBUG_URL_REQUEST_SUCCESS',
    data
  }
}

const clearDebugURLStateHandler = () => {
  return {
    type: 'DEBUG_URL_CLEAR'
  }
}

export const getMe = () => {
  return async (dispatch) => {
    dispatch(handleProfileRequest());
    meApi.fetchMe()
      .then((data) => dispatch(handleProfileRequestSuccess(data)))
      .catch((err) => dispatch(handleProfileRequestError(err)))
      ;
  }
};

// Debug URL request ends

export const postConfigure = (data) => async (dispatch) => {
  dispatch(handlePostConfigureInit());
  meApi.postConfigure(data)
    .then((data) => dispatch(handlePostConfigureSuccess(data)))
    .catch((err) => dispatch(handlePostConfigureFailure(err)));
}

export const getNetworkLogs = (token) => {
  return async (dispatch) => {
    dispatch(handleNetworkLogsRequestInit());

    let isAnyMessage = false;
    let networkLogMsgEventTimer;

    const startTimer = () => {
      networkLogMsgEventTimer = setInterval(() => {
        if (!isAnyMessage) {
          dispatch(setNetworkLogsStatus('Idle'));
        }
      }, NETWORK_LOGS_IDLE_TIMEOUT);
    }
    
    const ws = meApi.fetchNetworkLogs(token);

    // Listen for possible errors
    ws.onclose = (error) => {
      error.message = `Something went wrong while connecting to socket server. Code: ${error.code}`;
      dispatch(handleNetworkLogsRequestError(error));
    }

    ws.onmessage = (evt) => {
      // listen to data sent from the websocket server
      const message = JSON.parse(evt.data);
      if (message) {
        isAnyMessage = true;
        clearInterval(networkLogMsgEventTimer);
        dispatch(handleNetworkLogsRequestSuccess(message));
        isAnyMessage = false;
        startTimer();
      }
    }
  }
};

export const sendDebugConnectionRequest = (proxyParams) => {
  return async (dispatch) => {
    dispatch(handleDebugConnectionRequest());
    meApi.testDebugConnection(proxyParams)
    .then((data) => dispatch(handleDebugConnectionRequestSuccess(data)))
    .catch((err) => dispatch(handleDebugConnectionRequestError(err)))
    ;
  }
};

export const sendDebugURLRequest = (url, proxyParams) => {
  return async (dispatch) => {
    dispatch(handleDebugURLRequest());
    meApi.testDebugURL(url, proxyParams)
    .then((data) => dispatch(handleDebugURLRequestSuccess(data)))
    .catch((err) => dispatch(handleDebugConnectionRequestError(err)))
    ;
  }
};

export const clearDebugURLState = () => {
  return (dispatch) => {
    dispatch(clearDebugURLStateHandler());
  }
}
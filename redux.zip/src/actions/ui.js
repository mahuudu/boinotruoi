// Set UI
const handleSetUI = (ui, data) => {
  return {
    type: 'SET_UI',
    ui,
    data
  }
};

const handleResetUI = (ui) => {
  return {
    type: 'RESET_UI',
    ui
  }
};

export const setUI = (ui, data) => {
  return async (dispatch) => {
    dispatch(handleSetUI(ui, data));
  }
};

export const resetUI = (ui) =>
  async (dispatch) => dispatch(handleResetUI(ui));
;
